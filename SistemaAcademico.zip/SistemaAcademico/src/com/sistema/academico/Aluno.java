package com.sistema.academico;

import java.util.Objects;

//Estende a classe Pessoa
class Aluno extends Pessoa {
 private int matricula; // Número de matrícula do aluno
 private String curso; // Curso do aluno

 // Construtor da classe Aluno
 public Aluno(String nome, String email, int matricula, String curso) {
     super(nome, email); // Chama o construtor da superclasse Pessoa
     this.matricula = matricula;
     this.curso = curso;
 }

 // Método getter para a matrícula
 public int getMatricula() {
     return matricula;
 }

 // Método setter para a matrícula
 public void setMatricula(int matricula) {
     this.matricula = matricula;
 }

 // Método getter para o curso
 public String getCurso() {
     return curso;
 }

 // Método setter para o curso
 public void setCurso(String curso) {
     this.curso = curso;
 }

 // Sobrescreve o método exibirInfo() para incluir informações de Aluno
 @Override
 public void exibirInfo() {
     super.exibirInfo(); // Chama o método da superclasse
     System.out.println("Matrícula: " + matricula + ", Curso: " + curso);
 }

 // Sobrescreve o método equals para comparação de objetos Aluno
 @Override
 public boolean equals(Object o) {
     if (this == o) return true;
     if (o == null || getClass() != o.getClass()) return false;
     if (!super.equals(o)) return false; // Chama o equals da superclasse
     Aluno aluno = (Aluno) o;
     return matricula == aluno.matricula; // Compara a matrícula
 }

 // Sobrescreve o método hashCode
 @Override
 public int hashCode() {
     return Objects.hash(super.hashCode(), matricula); // Gera um hash baseado no hash da superclasse e matrícula
 }
}