package com.sistema.academico;

import java.util.ArrayList; // Importa a classe ArrayList
import java.util.List; // Importa a interface List

class GerenciadorAcademico {
    private List<Aluno> alunos; // Lista de alunos
    private List<Professor> professores; // Lista de professores
    private List<Disciplina> disciplinas; // Lista de disciplinas
    private List<Matricula> matriculas; // Lista de matrículas

    // Construtor da classe GerenciadorAcademico
    public GerenciadorAcademico() {
        this.alunos = new ArrayList<>();
        this.professores = new ArrayList<>();
        this.disciplinas = new ArrayList<>();
        this.matriculas = new ArrayList<>();
    }

    // Métodos para adicionar
    public void adicionarAluno(Aluno aluno) {
        if (!alunos.contains(aluno)) { // Verifica se o aluno já existe (encapsulamento)
            this.alunos.add(aluno);
            System.out.println("Aluno " + aluno.getNome() + " adicionado com sucesso.");
        } else {
            System.out.println("Erro: Aluno com matrícula " + aluno.getMatricula() + " já existe.");
        }
    }

    public void adicionarProfessor(Professor professor) {
        if (!professores.contains(professor)) { // Verifica se o professor já existe
            this.professores.add(professor);
            System.out.println("Professor " + professor.getNome() + " adicionado com sucesso.");
        } else {
            System.out.println("Erro: Professor " + professor.getNome() + " já existe.");
        }
    }

    public void adicionarDisciplina(Disciplina disciplina) {
        if (!disciplinas.contains(disciplina)) { // Verifica se a disciplina já existe
            this.disciplinas.add(disciplina);
            System.out.println("Disciplina " + disciplina.getNome() + " adicionada com sucesso.");
        } else {
            System.out.println("Erro: Disciplina com código " + disciplina.getCodigo() + " já existe.");
        }
    }

    public void adicionarMatricula(Matricula matricula) {
        // Verifica se o aluno e a disciplina existem antes de matricular
        boolean alunoExiste = alunos.contains(matricula.getAluno());
        boolean disciplinaExiste = disciplinas.contains(matricula.getDisciplina());

        if (alunoExiste && disciplinaExiste) {
            if (!matriculas.contains(matricula)) { // Verifica se a matrícula já existe
                this.matriculas.add(matricula);
                System.out.println("Matrícula realizada com sucesso para o aluno " + matricula.getAluno().getNome() + " na disciplina " + matricula.getDisciplina().getNome() + ".");
            } else {
                System.out.println("Erro: Matrícula para o aluno " + matricula.getAluno().getNome() + " na disciplina " + matricula.getDisciplina().getNome() + " e turma " + matricula.getTurma() + " já existe.");
            }
        } else {
            if (!alunoExiste) {
                System.out.println("Erro: Aluno " + matricula.getAluno().getNome() + " não encontrado para realizar a matrícula.");
            }
            if (!disciplinaExiste) {
                System.out.println("Erro: Disciplina " + matricula.getDisciplina().getNome() + " não encontrada para realizar a matrícula.");
            }
        }
    }

    // Métodos para buscar
    public Aluno buscarAlunoPorMatricula(int matricula) {
        for (Aluno a : alunos) {
            if (a.getMatricula() == matricula) {
                return a;
            }
        }
        return null; // Retorna null se não encontrar
    }

    public Professor buscarProfessorPorNome(String nome) {
        for (Professor p : professores) {
            if (p.getNome().equalsIgnoreCase(nome)) {
                return p;
            }
        }
        return null;
    }

    public Disciplina buscarDisciplinaPorCodigo(String codigo) {
        for (Disciplina d : disciplinas) {
            if (d.getCodigo().equalsIgnoreCase(codigo)) {
                return d;
            }
        }
        return null;
    }

    // Métodos para listar todos
    public void listarAlunos() {
        if (alunos.isEmpty()) {
            System.out.println("Nenhum aluno cadastrado.");
            return;
        }
        System.out.println("\n--- Lista de Alunos ---");
        for (Aluno a : alunos) {
            a.exibirInfo(); // Polimorfismo em ação
        }
    }

    public void listarProfessores() {
        if (professores.isEmpty()) {
            System.out.println("Nenhum professor cadastrado.");
            return;
        }
        System.out.println("\n--- Lista de Professores ---");
        for (Professor p : professores) {
            p.exibirInfo(); // Polimorfismo em ação
        }
    }

    public void listarDisciplinas() {
        if (disciplinas.isEmpty()) {
            System.out.println("Nenhuma disciplina cadastrada.");
            return;
        }
        System.out.println("\n--- Lista de Disciplinas ---");
        for (Disciplina d : disciplinas) {
            d.exibirInfo();
        }
    }

    public void listarMatriculas() {
        if (matriculas.isEmpty()) {
            System.out.println("Nenhuma matrícula realizada.");
            return;
        }
        System.out.println("\n--- Lista de Matrículas ---");
        for (Matricula m : matriculas) {
            m.exibirInfo();
        }
    }

    // Funcionalidades avançadas:
    // Listar disciplinas de um professor
    public void listarDisciplinasPorProfessor(String nomeProfessor) {
        Professor professor = buscarProfessorPorNome(nomeProfessor);
        if (professor == null) {
            System.out.println("Professor '" + nomeProfessor + "' não encontrado.");
            return;
        }

        System.out.println("\n--- Disciplinas ministradas por " + professor.getNome() + " ---");
        boolean encontrou = false;
        for (Disciplina d : disciplinas) {
            if (d.getProfessor() != null && d.getProfessor().equals(professor)) {
                d.exibirInfo();
                encontrou = true;
            }
        }
        if (!encontrou) {
            System.out.println("Nenhuma disciplina encontrada para este professor.");
        }
    }

    // Listar alunos matriculados em uma disciplina
    public void listarAlunosPorDisciplina(String codigoDisciplina) {
        Disciplina disciplina = buscarDisciplinaPorCodigo(codigoDisciplina);
        if (disciplina == null) {
            System.out.println("Disciplina com código '" + codigoDisciplina + "' não encontrada.");
            return;
        }

        System.out.println("\n--- Alunos matriculados em " + disciplina.getNome() + " ---");
        boolean encontrou = false;
        for (Matricula m : matriculas) {
            if (m.getDisciplina().equals(disciplina)) {
                m.getAluno().exibirInfo();
                encontrou = true;
            }
        }
        if (!encontrou) {
            System.out.println("Nenhum aluno matriculado nesta disciplina.");
        }
    }

    // Listar disciplinas de um aluno
    public void listarDisciplinasPorAluno(int matriculaAluno) {
        Aluno aluno = buscarAlunoPorMatricula(matriculaAluno);
        if (aluno == null) {
            System.out.println("Aluno com matrícula '" + matriculaAluno + "' não encontrado.");
            return;
        }

        System.out.println("\n--- Disciplinas matriculadas pelo aluno " + aluno.getNome() + " ---");
        boolean encontrou = false;
        for (Matricula m : matriculas) {
            if (m.getAluno().equals(aluno)) {
                m.getDisciplina().exibirInfo();
                encontrou = true;
            }
        }
        if (!encontrou) {
            System.out.println("Nenhuma disciplina encontrada para este aluno.");
        }
    }
}
