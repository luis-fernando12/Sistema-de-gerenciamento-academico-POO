package com.sistema.academico;

import java.util.Objects;

class Pessoa {
    private String nome;
    private String email;

    public Pessoa(String nome, String email) {
        this.nome = nome;
        this.email = email;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void exibirInfo() {
        System.out.println("Nome: " + nome + ", Email: " + email);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true; // Se forem o mesmo objeto, retorna true
        if (o == null || getClass() != o.getClass()) return false; // Se o objeto é nulo ou de classe diferente, retorna false
        Pessoa pessoa = (Pessoa) o; // Converte o objeto para Pessoa
        return Objects.equals(nome, pessoa.nome) && // Compara os nomes
               Objects.equals(email, pessoa.email); // Compara os emails
    }

    // Sobrescreve o método hashCode
    @Override
    public int hashCode() {
        return Objects.hash(nome, email); // Gera um hash baseado em nome e email
    }
}