package com.sistema.academico;

import java.util.Objects;

//Estende a classe Pessoa
class Professor extends Pessoa {
 private String departamento; // Departamento do professor
 private String especializacao; // Especialização do professor

 // Construtor da classe Professor
 public Professor(String nome, String email, String departamento, String especializacao) {
     super(nome, email); // Chama o construtor da superclasse Pessoa
     this.departamento = departamento;
     this.especializacao = especializacao;
 }

 // Método getter para o departamento
 public String getDepartamento() {
     return departamento;
 }

 // Método setter para o departamento
 public void setDepartamento(String departamento) {
     this.departamento = departamento;
 }

 // Método getter para a especialização
 public String getEspecializacao() {
     return especializacao;
 }

 // Método setter para a especialização
 public void setEspecializacao(String especializacao) {
     this.especializacao = especializacao;
 }

 // Sobrescreve o método exibirInfo() para incluir informações de Professor
 @Override
 public void exibirInfo() {
     super.exibirInfo(); // Chama o método da superclasse
     System.out.println("Departamento: " + departamento + ", Especialização: " + especializacao);
 }

 // Sobrescreve o método equals para comparação de objetos Professor
 @Override
 public boolean equals(Object o) {
     if (this == o) return true;
     if (o == null || getClass() != o.getClass()) return false;
     if (!super.equals(o)) return false;
     Professor professor = (Professor) o;
     return Objects.equals(departamento, professor.departamento) &&
            Objects.equals(especializacao, professor.especializacao);
 }

 // Sobrescreve o método hashCode
 @Override
 public int hashCode() {
     return Objects.hash(super.hashCode(), departamento, especializacao);
 }
}