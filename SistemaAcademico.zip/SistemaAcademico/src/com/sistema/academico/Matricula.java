package com.sistema.academico;

import java.util.Objects;

class Matricula {
    private Aluno aluno; // Aluno matriculado
    private Disciplina disciplina; // Disciplina em que o aluno está matriculado
    private String turma; // Turma da matrícula

    // Construtor da classe Matricula
    public Matricula(Aluno aluno, Disciplina disciplina, String turma) {
        this.aluno = aluno;
        this.disciplina = disciplina;
        this.turma = turma;
    }

    // Método getter para o aluno
    public Aluno getAluno() {
        return aluno;
    }

    // Método setter para o aluno
    public void setAluno(Aluno aluno) {
        this.aluno = aluno;
    }

    // Método getter para a disciplina
    public Disciplina getDisciplina() {
        return disciplina;
    }

    // Método setter para a disciplina
    public void setDisciplina(Disciplina disciplina) {
        this.disciplina = disciplina;
    }

    // Método getter para a turma
    public String getTurma() {
        return turma;
    }

    // Método setter para a turma
    public void setTurma(String turma) {
        this.turma = turma;
    }

    // Método para exibir informações da matrícula
    public void exibirInfo() {
        System.out.println("--- Detalhes da Matrícula ---");
        System.out.print("Aluno: ");
        if (aluno != null) {
            aluno.exibirInfo(); // Exibe informações do aluno
        } else {
            System.out.println("Aluno não encontrado.");
        }
        System.out.print("Disciplina: ");
        if (disciplina != null) {
            disciplina.exibirInfo(); // Exibe informações da disciplina
        } else {
            System.out.println("Disciplina não encontrada.");
        }
        System.out.println("Turma: " + turma);
    }

    // Sobrescreve o método equals para comparação de objetos Matricula
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Matricula matricula1 = (Matricula) o;
        return Objects.equals(aluno, matricula1.aluno) &&
               Objects.equals(disciplina, matricula1.disciplina) &&
               Objects.equals(turma, matricula1.turma);
    }

    // Sobrescreve o método hashCode
    @Override
    public int hashCode() {
        return Objects.hash(aluno, disciplina, turma);
    }
}
