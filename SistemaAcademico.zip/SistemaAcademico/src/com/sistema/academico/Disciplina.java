package com.sistema.academico;

import java.util.Objects;

class Disciplina {
    private String codigo; // Código da disciplina
    private String nome; // Nome da disciplina
    private int cargaHoraria; // Carga horária da disciplina
    private Professor professor; // Professor responsável pela disciplina

    // Construtor da classe Disciplina
    public Disciplina(String codigo, String nome, int cargaHoraria, Professor professor) {
        this.codigo = codigo;
        this.nome = nome;
        this.cargaHoraria = cargaHoraria;
        this.professor = professor;
    }

    // Método getter para o código
    public String getCodigo() {
        return codigo;
    }

    // Método setter para o código
    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    // Método getter para o nome
    public String getNome() {
        return nome;
    }

    // Método setter para o nome
    public void setNome(String nome) {
        this.nome = nome;
    }

    // Método getter para a carga horária
    public int getCargaHoraria() {
        return cargaHoraria;
    }

    // Método setter para a carga horária
    public void setCargaHoraria(int cargaHoraria) {
        this.cargaHoraria = cargaHoraria;
    }

    // Método getter para o professor
    public Professor getProfessor() {
        return professor;
    }

    // Método setter para o professor
    public void setProfessor(Professor professor) {
        this.professor = professor;
    }

    // Método para exibir informações da disciplina
    public void exibirInfo() {
        System.out.println("Código: " + codigo + ", Nome: " + nome + ", Carga Horária: " + cargaHoraria + "h");
        System.out.print("Professor: ");
        if (professor != null) {
            professor.exibirInfo(); // Chama o método exibirInfo do professor
        } else {
            System.out.println("Nenhum professor atribuído.");
        }
    }

    // Sobrescreve o método equals para comparação de objetos Disciplina
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Disciplina that = (Disciplina) o;
        return cargaHoraria == that.cargaHoraria &&
               Objects.equals(codigo, that.codigo) &&
               Objects.equals(nome, that.nome) &&
               Objects.equals(professor, that.professor);
    }

    // Sobrescreve o método hashCode
    @Override
    public int hashCode() {
        return Objects.hash(codigo, nome, cargaHoraria, professor);
    }
}
